#ifndef ZBLUENET_NET_TCP_SOCKET_H
#define ZBLUENET_NET_TCP_SOCKET_H

#include <cstddef>
#include <zbluenet/class_util.h>
#include <zbluenet/net/platform.h>
#include <zbluenet/net/socket_address.h>
#include <zbluenet/net/network.h>

namespace zbluenet {
	namespace net {

		class TcpSocket : public Noncopyable {
		public:
			TcpSocket();
			virtual ~TcpSocket();

			bool open(SocketAddress::Protocol::type protocol);
			void close();
			bool connect(const SocketAddress &addr);
			bool bind(const SocketAddress &addr);
			bool listen(int backlog);
			bool accept(TcpSocket *peer_socket);

			bool getLocalAddress(SocketAddress *addr) const;
			bool getPeerAddress(SocketAddress *addr) const;

			int readableBytes() const;
			int recv(char *buffer, size_t size);
			int send(const char *buffer, size_t size);

			bool shutdownRead();
			bool shutdownWrite();
			bool shutdownBoth();

			int getSocketError();
			bool setReuseAddr();
			bool setTcpNoDelay();

			// �ͻ��˷�������
			/************************************************************************/
			/* open setReuseAaddr setTcpNodealy connect                                                                     */
			/************************************************************************/
			bool activeOpen(const SocketAddress &remote_addr);
			
			/************************************************************************/
			/* activeOpen setNonblock                                                                     */
			/************************************************************************/
			bool activeOpenNonblock(const SocketAddress &remote_addr);

			// ��������
			/************************************************************************/
			/* open setReuseAddr setTcpNodelay bind listen(128)                                                                     */
			/************************************************************************/
			bool passiveOpen(const SocketAddress &local_addr);
			
			/************************************************************************/
			/* passiveOpen setNonblock                                                                     */
			/************************************************************************/
			bool passiveOpenNonblock(const SocketAddress &local_addr);

			/************************************************************************/
			/* accept setTcpNodelay setNonblock                                                                     */
			/************************************************************************/
			bool acceptNonblock(TcpSocket *peer);

		private:
			SOCKET fd_;
		};

	} // namespace net
} // namespace zbluenet

#endif // ZBLUENET_NET_TCP_SOCKET_H
