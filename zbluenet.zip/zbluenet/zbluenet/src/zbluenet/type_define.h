#ifndef ZBLUENET_TYPE_DEFINE_H
#define ZBLUENET_TYPE_DEFINE_H

#include <stdint.h>

class zbluenet_type {
public:
	using TimerId = int64_t;

};

#endif // ZBLUENET_TYPE_DEFINE_H
